package encryption;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import com.douglei.tools.instances.file.writer.FileBufferedWriter;
import com.douglei.tools.utils.CryptographyUtil;

public class Do {
	public static void main(String[] args) {
		System.out.println("欢迎进入加密系统");
		String str;
		FileBufferedWriter writer = new FileBufferedWriter(targetFile);
		try {
			do {
				System.out.println("请输入你要加密的字符串, 如果想要结束, 请输入EXIT:");
				str = scanner.next();
				if("EXIT".equals(str)) {
					break;
				}
				writer.write(str);
				writer.write("------");
				writer.write(CryptographyUtil.encodeWithBASE64(str));
				writer.newLine();
			}while(true);
			writer.close();
			System.out.println("加密结束, 请去以下文件中获取你的加密数据");
			System.out.println("注意: 每行数据------前的为源数据, ------后才是加密后的数据");
			System.out.println("注意: 每行数据------前的为源数据, ------后才是加密后的数据");
			System.out.println("注意: 每行数据------前的为源数据, ------后才是加密后的数据");
			System.out.println(targetFile);
			System.out.println("确认后, 直接关闭该窗口来结束程序");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("你的程序出问题了, 不要关闭该窗口, 并联系开发人员");
			System.out.println("你的程序出问题了, 不要关闭该窗口, 并联系开发人员");
			System.out.println("你的程序出问题了, 不要关闭该窗口, 并联系开发人员");
			scanner.next();
			scanner.next();
		}
		scanner.next();
	}
	
	private static final Scanner scanner = new Scanner(System.in);
	private static final File targetFile = new File(System.getProperty("user.home") + File.separatorChar + "encryption.txt");
	static {
		if(targetFile.exists()) {
			targetFile.delete();
		}
	}
}
